
public class painterInputThread {

}
