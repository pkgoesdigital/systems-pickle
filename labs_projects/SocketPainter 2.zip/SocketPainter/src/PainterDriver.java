import javax.swing.JFrame;
import java.awt.event.*;
import javax.swing.*;

public class PainterDriver extends JFrame{

	public static void main(String[] args) {
		
		Painter p = new Painter();
		
		

	}

}
